/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package massaging.app;

import java.util.Scanner;

public class MassagingApp {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        Login login = new Login();

        // 🔹 Registration
        System.out.println("=== Register ===");

        System.out.print("Enter username: ");
        String username = input.nextLine();

        System.out.print("Enter password: ");
        String password = input.nextLine();

        System.out.print("Enter phone (+27...): ");
        String phone = input.nextLine();

        String registerMessage = login.registerUser(username, password, phone);
        System.out.println(registerMessage);

        // 🔹 Login
        System.out.println("\n=== Login ===");

        System.out.print("Enter username: ");
        String loginUser = input.nextLine();

        System.out.print("Enter password: ");
        String loginPass = input.nextLine();

        boolean isLoggedIn = login.loginUser(loginUser, loginPass);

        String message = login.returnLoginStatus(isLoggedIn, "Given", "Mutshosho");
        System.out.println(message);
    }
}