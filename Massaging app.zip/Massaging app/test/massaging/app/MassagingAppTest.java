/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package massaging.app;


import org.junit.Before;
import org.junit.Test;

import static org.hamcrest.CoreMatchers.*;
import static org.junit.Assert.*;

public class MassagingAppTest {

    private Login login;

    @Before
    public void setUp() {
        login = new Login();
    }

    // 🔹 Username Tests
    @Test
    public void testUsernameValid() {
        assertThat(login.checkUserName("ky_1"), is(true));
    }

    @Test
    public void testUsernameInvalid() {
        assertThat(login.checkUserName("kyle!!!!!!"), is(false));
    }

    // 🔹 Password Tests
    @Test
    public void testPasswordValid() {
        assertThat(login.checkPasswordComplexity("Ch&&sec@ke991"), is(true));
    }

    @Test
    public void testPasswordInvalid() {
        assertThat(login.checkPasswordComplexity("password"), is(false));
    }

    // 🔹 Phone Tests
    @Test
    public void testPhoneValid() {
        assertThat(login.checkCellPhoneNumber("+27838968976"), is(true));
    }

    @Test
    public void testPhoneInvalid() {
        assertThat(login.checkCellPhoneNumber("08966553"), is(false));
    }

    // 🔹 Register Tests
    @Test
    public void testRegisterSuccess() {
        String result = login.registerUser("ky_1", "Ch&&sec@ke991", "+27838968976");
        assertThat(result, is("User successfully registered."));
    }

    @Test
    public void testRegisterFailUsername() {
        String result = login.registerUser("wrongname", "Ch&&sec@ke991", "+27838968976");
        assertThat(result, containsString("Username is not correctly formatted"));
    }

    @Test
    public void testRegisterFailPassword() {
        String result = login.registerUser("ky_1", "password", "+27838968976");
        assertThat(result, containsString("Password is not correctly formatted"));
    }

    @Test
    public void testRegisterFailPhone() {
        String result = login.registerUser("ky_1", "Ch&&sec@ke991", "08966553");
        assertThat(result, containsString("Cell number is incorrectly formatted"));
    }

    // 🔹 Login Tests
    @Test
    public void testLoginSuccess() {
        login.registerUser("ky_1", "Ch&&sec@ke991", "+27838968976");
        assertThat(login.loginUser("ky_1", "Ch&&sec@ke991"), is(true));
    }

    @Test
    public void testLoginFail() {
        login.registerUser("ky_1", "Ch&&sec@ke991", "+27838968976");
        assertThat(login.loginUser("ky_1", "wrong"), is(false));
    }

    // 🔹 Login Message Tests
    @Test
    public void testLoginMessageSuccess() {
        String msg = login.returnLoginStatus(true, "Given", "Mutshosho");
        assertThat(msg, is("Welcome Given Mutshosho, it is great to see you again."));
    }

    @Test
    public void testLoginMessageFail() {
        String msg = login.returnLoginStatus(false, "Given", "Mutshosho");
        assertThat(msg, is("Username or password incorrect, please try again."));
    }
}